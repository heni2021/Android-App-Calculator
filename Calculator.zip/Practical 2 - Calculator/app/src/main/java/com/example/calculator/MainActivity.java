package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    public final static boolean PLUS = true;
    public final static boolean MINUS = false;
    public static boolean currentSign = PLUS;

    public static double answer = 0;
    boolean p=false,m=false,d=false,mul=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivateButtons();

    }
    public void ActivateButtons(){
        Button button1 = findViewById(R.id.button12);
        Button button2 = findViewById(R.id.button11);
        Button button3 = findViewById(R.id.button10);
        Button button4 = findViewById(R.id.button15);
        Button button5 = findViewById(R.id.button14);
        Button button6 = findViewById(R.id.button13);
        Button button7 = findViewById(R.id.button18);
        Button button8 = findViewById(R.id.button17);
        Button button9 = findViewById(R.id.button16);
        Button button0 = findViewById(R.id.button5);
        Button button00 = findViewById(R.id.button3);
        Button dot = findViewById(R.id.button4);
        Button plus = findViewById(R.id.button6);
        Button minus = findViewById(R.id.button2);
        Button multiply = findViewById(R.id.button7);
        Button divide = findViewById(R.id.button8);
        Button signChange = findViewById(R.id.button9);



        Button equals = findViewById(R.id.button);

        Button erase = findViewById(R.id.button20);
        Button clearAll = findViewById(R.id.button19);

        EditText textField = findViewById(R.id.editTextText2);


        signChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                if(currentSign){
                    currentText = "-";
                    currentText+=textField.getText().toString();
                    currentSign=MINUS;
                }
                else{
                    currentSign=PLUS;
                    currentText+=textField.getText().toString();
                    Log.d("Current Text: ",currentText);
                    if(currentText.length()>1) {
                        currentText = currentText.substring(1, currentText.length());
                        Log.d("After Plus : ",currentText.substring(1, currentText.length()));
                    }
                    else
                        currentText = "+";
                }
                textField.setText(currentText);
            }
        });

        equals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentValue = textField.getText().toString();
                if(p){
                    answer+=Double.parseDouble(currentValue);
                }
                else if(m){
                    answer-=Double.parseDouble(currentValue);

                }
                else if(mul){
                    answer*=Double.parseDouble(currentValue);

                }
                else if(d){
                    answer/=Double.parseDouble(currentValue);
                }
                textField.setText(String.valueOf(answer));
                Log.i("Equals ", textField.getText().toString());
                p=false;
                m=false;
                mul=false;
                d=false;
            }
        });

        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                Log.d("Multiply", currentText);
                if(answer==0){
                    answer = Double.parseDouble(currentText);
                }
                else
                    answer*=Double.parseDouble(currentText);
                Log.d("Answer : ", String.valueOf(answer));
                mul=true;
                p=false;
                d=false;
                m=false;
                textField.setText("");
            }
        });

        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                Log.d("Divide", currentText);
                if(answer==0){
                    answer = Double.parseDouble(currentText);
                }
                else
                 answer/=Double.parseDouble(currentText);
                Log.d("Answer : ", String.valueOf(answer));
                mul=false;
                p=false;
                d=true;
                m=false;
                textField.setText("");
            }
        });

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                Log.d("Plus", currentText);
                answer+=Double.parseDouble(currentText);
                Log.d("Answer : ", String.valueOf(answer));
                mul=false;
                m=false;
                d=false;
                p=true;
                textField.setText("");
            }
        });

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                Log.d("Minus", currentText);
                if(answer==0){
                    answer = Double.parseDouble(currentText);
                }
                else
                    answer-=Double.parseDouble(currentText);
                Log.d("Answer : ", String.valueOf(answer));
                textField.setText("");
                mul=false;
                p=false;
                d=false;
                m=true;
            }
        });

        dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                currentText+=".";
                textField.setText(currentText);
            }
        });


        button00.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                currentText+="00";
                textField.setText(currentText);
            }
        });

        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                currentText+="0";
                textField.setText(currentText);
            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                currentText+="1";
                textField.setText(currentText);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                currentText+="2";
                textField.setText(currentText);
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                currentText+="3";
                textField.setText(currentText);
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                currentText+="4";
                textField.setText(currentText);
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                currentText+="5";
                textField.setText(currentText);
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                currentText+="6";
                textField.setText(currentText);
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                currentText+="7";
                textField.setText(currentText);
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                currentText+="8";
                textField.setText(currentText);
            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                currentText+="9";
                textField.setText(currentText);
            }
        });

        erase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                currentText=textField.getText().toString();
                if(currentText.length()>0)
                    currentText = currentText.substring(0, currentText.length()-1);
                textField.setText(currentText);
            }
        });

        clearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = "";
                answer = 0;
                textField.setText(currentText);
                p=false;
                m=false;
                mul=false;
                d=false;
            }
        });
    }
}